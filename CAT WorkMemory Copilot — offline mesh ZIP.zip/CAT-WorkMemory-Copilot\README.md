# CAT WorkMemory + Context Guardian

A software-only, operator-first hackathon prototype for CAT machinery.

> Sensors tell you what the machine did. Operators tell you why.

CAT WorkMemory captures practical operator observations and turns them into task-, site-, machine-, and condition-specific guidance for the next operator. Context Guardian explains whether a delay was caused by the operator, machine, weather, site, or another team before it becomes a performance judgement.

## Included

- Operator workspace: My Shift, Current Task, 3D Vehicle, Site Memory, Learn, Handover
- Supervisor workspace: Context Guardian review queue and site knowledge feed
- Interactive real GLB vehicle model with drag/orbit controls, rotate/reset controls, component hotspots, and live component details
- Local-first WorkMemory Mesh: service-worker app cache, bundled Three.js modules, bundled GLB model, cached state, and a durable offline event queue
- Continuous reconciliation: queued reports and simulated events retry every 8 seconds and flush when the browser comes online
- Visible Online, Offline, Syncing, retry, and pending-event status in the operator header

## Offline / online mesh

The browser client is designed as an operator node. It can open the cached application and 3D vehicle without internet, read the last known state, and capture reports or events into a local queue. When connectivity returns, the mesh sends each queued event to the Node API in order and refreshes the shared state.

This is software mesh synchronization, not a radio or Bluetooth mesh. A real multi-device site mesh would need a local gateway, WebRTC/WebSocket peers, or an edge server; this prototype keeps the operator experience functional and demonstrates the sync contract without requiring hardware.

## 3D asset note

The downloaded `small.glb` model is bundled at `public/models/small.glb`, so the demo works offline. It originated from the public `arturbien/3D-excavator` project. The repository did not expose a clear license file during inspection, so treat this as a hackathon/demo asset only. Before public or commercial distribution, replace it with a CAT-authorized or clearly licensed GLB/GLTF asset and add attribution as required.
- Simulated telemetry, task history, weather, operator skill, and machine age
- Task-time prediction with explanation of the factors affecting the estimate
- Delay recovery categories: waiting for truck, site condition, machine issue, safety concern, or guidance
- Voice-to-text issue reporting when supported by the browser
- Automatic site-memory creation from operator reports
- Automatic shift handover generation
- Safety blocker simulation for seatbelt status
- No external dependencies and no hardware required

## Run locally

Requires Node.js 18 or newer.

```bash
npm start
```

Open http://localhost:3000.

## Suggested demo flow

1. Open My Shift and show T002 Trenching: rainy conditions, intermediate operator, predicted 52 minutes.
2. Explain the wet-ground site memory and the next best action.
3. Open Current Task and capture a site condition by text or voice.
4. Use Supervisor view to show that the observation becomes structured memory.
5. To simulate a safety event, call `POST /api/simulate` with `{ "event": "seatbelt" }` using a REST client, or add a demo button.
6. Resolve the blocker and show the safety state returning to clear.
7. Capture “Waiting for truck” as a delay reason and explain that it is not automatically scored as operator inefficiency.
8. Open Handover to show completed work, outstanding work, site memories, delay context, and next-operator guidance.

## Files

- `server.js`: zero-dependency Node.js server, in-memory demo API, simulated telemetry, reports, and handover generator.
- `public/index.html`: app shell.
- `public/styles.css`: responsive operator-first visual system.
- `public/app.js`: view rendering, reporting, voice input, safety simulation, supervisor review, handover flow, and local GLB viewer.
- `public/mesh.js`: local-first fetch layer, durable queue, optimistic offline state, retry loop, and mesh status indicator.
- `public/sw.js`: service worker that caches the app shell, vendor modules, API responses, and GLB model.
- `public/vendor/`: locally bundled Three.js, GLTFLoader, and OrbitControls modules.
- `public/models/small.glb`: bundled excavator model for offline 3D inspection.
- `PRODUCT-NARRATIVE.md`: product story, differentiation, primary journey, and real-deployment metrics.

## Production path

Replace the in-memory API with adapters for existing CAT data sources. Add authentication, audit trails, offline sync, role permissions, location/privacy controls, and a review workflow for high-impact memories.

## AI boundaries

Safety blockers and escalation should remain deterministic. AI can help with speech-to-structured reporting, plain-language explanations, memory summarization, and handover drafting. It must not override safety rules or make unreviewed employment decisions.

## Positioning

Existing systems monitor and report machine performance. CAT WorkMemory adds the operator's context and creates a learning loop:

`operator observation -> structured memory -> recommended action -> task outcome -> improved future guidance`
