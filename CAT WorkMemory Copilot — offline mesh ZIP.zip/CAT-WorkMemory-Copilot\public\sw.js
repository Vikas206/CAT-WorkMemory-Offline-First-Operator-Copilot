const CACHE = 'workmemory-offline-v5';
const SHELL = [
  '/', '/index.html', '/styles.css', '/vehicle-glb-overrides.css', '/mesh.js', '/app.js',
  '/vendor/three.module.js', '/vendor/loaders/GLTFLoader.js', '/vendor/controls/OrbitControls.js', '/vendor/utils/BufferGeometryUtils.js',
  '/models/small.glb'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(async cache => {
    for (const asset of SHELL) {
      try { await cache.add(asset); } catch (_) { /* The runtime fetch path can cache it later. */ }
    }
    await self.skipWaiting();
  }));
});
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(request).then(response => {
      if (response.ok) caches.open(CACHE).then(cache => cache.put(request, response.clone()));
      return response;
    }).catch(() => caches.match(request).then(cached => cached || new Response(JSON.stringify({ offline: true, error: 'No cached response available' }), { status: 503, headers: { 'Content-Type': 'application/json' } }))));
    return;
  }
  event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
    if (response.ok) caches.open(CACHE).then(cache => cache.put(request, response.clone()));
    return response;
  })));
});
