@echo off
setlocal
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required.
  pause
  exit /b 1
)
start "CAT WorkMemory" cmd /k "node server.js"
timeout /t 2 /nobreak >nul
start "" http://localhost:3000
