(() => {
  const QUEUE_KEY = 'workmemory.mesh.queue.v1';
  const STATE_KEY = 'workmemory.mesh.last-state.v1';
  const CLIENT_KEY = 'workmemory.mesh.client-id.v1';
  const clientId = localStorage.getItem(CLIENT_KEY) || `operator-${crypto.randomUUID ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10)}`;
  localStorage.setItem(CLIENT_KEY, clientId);
  let syncing = false;
  let lastOnlineSync = null;

  const readQueue = () => { try { return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]'); } catch (_) { return []; } };
  const writeQueue = queue => localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  const readState = () => { try { return JSON.parse(localStorage.getItem(STATE_KEY) || 'null'); } catch (_) { return null; } };
  const writeState = value => { if (value) localStorage.setItem(STATE_KEY, JSON.stringify(value)); };
  const queueCount = () => readQueue().length;

  function setStatus(mode, detail) {
    const el = document.getElementById('meshConnection') || document.querySelector('.connection');
    if (!el) return;
    el.id = 'meshConnection';
    el.className = `connection mesh-${mode}`;
    const labels = {
      online: 'Online · live sync',
      offline: 'Offline · local mode',
      syncing: 'Syncing · mesh reconciliation',
      queued: 'Offline · pending sync',
      error: 'Online · retrying sync'
    };
    const pending = queueCount();
    el.innerHTML = `<i></i><span>${detail || labels[mode] || labels.online}</span>${pending ? `<b class="mesh-pending">${pending} pending</b>` : ''}`;
    el.title = `${labels[mode] || labels.online}${pending ? ` · ${pending} event${pending === 1 ? '' : 's'} waiting` : ''}`;
    document.documentElement.dataset.mesh = mode;
  }

  function showMeshToast(text) {
    if (typeof window.toast === 'function') window.toast(text);
  }

  function locallyApply(url, options, current) {
    const next = current ? JSON.parse(JSON.stringify(current)) : null;
    if (!next) return next;
    let body = {};
    try { body = JSON.parse(options.body || '{}'); } catch (_) { return next; }
    next.mesh = { ...(next.mesh || {}), clientId, locallyUpdatedAt: new Date().toISOString() };
    if (url.endsWith('/api/simulate')) {
      if (body.event === 'seatbelt') {
        next.telemetry.seatbelt = 'Unfastened'; next.safety.blocked = true; next.safety.lastEvent = 'Seatbelt status unsafe';
      }
      if (body.event === 'resolveSeatbelt') {
        next.telemetry.seatbelt = 'Fastened'; next.safety.blocked = false; next.safety.lastEvent = null;
      }
      if (body.event === 'truckWait') {
        next.telemetry.idleMinutes = 63; next.currentTask.predictedMinutes = 59;
      }
    }
    if (url.endsWith('/api/report')) {
      const report = { id: `LOCAL-${Date.now()}`, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }), source: next.operator.id, severity: body.severity || 'Medium', ...body };
      next.reports = [report, ...(next.reports || [])];
      next.timeline = [...(next.timeline || []), { time: report.time, title: 'Offline operator report queued', detail: report.title }];
      if (report.category === 'Site condition') next.memories = [{ id: `LOCAL-M-${Date.now()}`, kind: 'Site', title: report.title, body: report.detail, task: next.currentTask.type, confidence: 'Pending', uses: 1, updated: 'Offline · just now', author: next.operator.id }, ...(next.memories || [])];
    }
    return next;
  }

  async function send(url, options) {
    const response = await originalFetch(url, options);
    if (response.ok) {
      try {
        const data = await response.clone().json();
        if (data.state) writeState(data.state); else if (url.endsWith('/api/state')) writeState(data);
      } catch (_) {}
    }
    return response;
  }

  async function flushQueue() {
    if (syncing || !navigator.onLine || !queueCount()) { if (!navigator.onLine) setStatus('offline'); return; }
    syncing = true; setStatus('syncing');
    const pending = readQueue(); const remaining = [];
    for (const item of pending) {
      try {
        const response = await originalFetch(item.url, { method: item.method, headers: item.headers, body: item.body });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        try { const data = await response.clone().json(); if (data.state) writeState(data.state); } catch (_) {}
      } catch (_) { remaining.push(item); }
    }
    writeQueue(remaining); syncing = false; lastOnlineSync = new Date();
    if (remaining.length) setStatus('error'); else { setStatus('online'); if (typeof window.refreshState === 'function') window.refreshState(true); }
    if (pending.length && !remaining.length) showMeshToast('Offline events synchronized with the live server.');
  }

  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input, options = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const method = (options.method || (typeof input !== 'string' ? input.method : 'GET')).toUpperCase();
    if (!url.includes('/api/')) return originalFetch(input, options);
    if (method === 'GET') {
      try {
        const response = await originalFetch(input, options);
        if (response.ok) { try { writeState(await response.clone().json()); } catch (_) {} }
        setStatus(navigator.onLine ? 'online' : 'offline');
        return response;
      } catch (_) {
        const cached = readState();
        if (cached) { setStatus('offline'); return new Response(JSON.stringify(cached), { status: 200, headers: { 'Content-Type': 'application/json' } }); }
        setStatus('offline'); throw _;
      }
    }
    try {
      const response = await send(input, options);
      setStatus(navigator.onLine ? 'online' : 'offline');
      return response;
    } catch (_) {
      const item = { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), url, method, headers: options.headers || { 'Content-Type': 'application/json' }, body: options.body || null, queuedAt: new Date().toISOString(), clientId };
      writeQueue([...readQueue(), item]);
      const optimistic = locallyApply(url, options, readState());
      writeState(optimistic);
      setStatus('queued');
      return new Response(JSON.stringify({ queued: true, state: optimistic, mesh: { clientId, queued: true } }), { status: 202, headers: { 'Content-Type': 'application/json' } });
    }
  };

  window.workMemoryMesh = { clientId, flushQueue, getQueue: readQueue, getCachedState: readState, status: () => ({ online: navigator.onLine, pending: queueCount(), lastOnlineSync }) };
  window.addEventListener('online', () => { setStatus(queueCount() ? 'syncing' : 'online'); flushQueue(); });
  window.addEventListener('offline', () => setStatus('offline'));
  window.addEventListener('load', () => { setStatus(navigator.onLine ? (queueCount() ? 'queued' : 'online') : 'offline'); flushQueue(); setInterval(flushQueue, 8000); });
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').then(reg => { window.__workMemoryServiceWorker = reg; }).catch(error => { window.__workMemoryServiceWorkerError = error.message; });
})();
