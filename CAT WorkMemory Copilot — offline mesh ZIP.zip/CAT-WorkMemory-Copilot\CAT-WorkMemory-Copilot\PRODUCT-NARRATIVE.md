# Product narrative

## Problem

Fleet and machine platforms are good at showing what happened: idle time, machine events, task variance, fuel use, and safety alerts. The operator still has to explain why it happened and what should happen next. That context is often lost between shifts.

## Solution

CAT WorkMemory is a software-only operator copilot that captures practical field knowledge and delivers it at the moment of work. Context Guardian prevents raw telemetry from becoming an unfair performance judgement by asking for the reason behind a delay.

## Differentiation

1. Operator-first, not fleet-first.
2. Site-specific memory, not generic dashboards.
3. Reason-aware performance, not automatic blame.
4. Voice-first reporting, not paperwork.
5. Closed-loop learning, not one-time alerts.
6. Works as a software layer over existing systems and does not require new hardware.

## Primary user journey

- Start shift: receive the current task and relevant site memory.
- Start task: pass the deterministic safe-to-work gate.
- During task: receive one next action rather than many alerts.
- Delay: identify the cause with one tap or voice.
- Observe: capture a site condition or technique.
- End shift: produce a living handover for the next operator.

## Hackathon promise

When the machine is late, existing systems tell you that it is late. CAT WorkMemory learns why and helps ensure the next operator does not face the same problem.

## Metrics for a real deployment

- Percentage of delay events with a confirmed cause
- Reduction in repeated site-condition delays
- Time required to report an issue
- Handover completeness and next-shift recovery time
- Percentage of operator recommendations accepted as useful
- False-positive rate for operator performance flags
- Safety blocker resolution time
