const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');

const state = {
  operator: { id: 'OP1001', name: 'Arjun Mehta', skill: 'Intermediate', shift: '07:00–15:00' },
  machine: { id: 'EXC001', type: 'Excavator', age: 4, engineHours: 1524.8 },
  telemetry: { fuelUsed: 3.8, loadCycles: 2, idleMinutes: 55, seatbelt: 'Fastened', proximity: 'Clear', connected: true },
  currentTask: { id: 'T002', type: 'Trenching', weather: 'Rainy', baselineEstimate: 45, predictedMinutes: 52, elapsedMinutes: 34, progress: 64, status: 'In progress', location: 'East trench' },
  reports: [
    { id: 'R-104', time: '10:20', category: 'Site condition', title: 'Soft ground on east side', detail: 'Reduced bucket load and operating speed after rain.', location: 'East trench', severity: 'Medium', source: 'OP1001' },
    { id: 'R-103', time: '09:48', category: 'Workflow delay', title: 'Waiting for truck', detail: 'Truck queue at loading point caused productive waiting.', location: 'Loading point A', severity: 'Low', source: 'OP1001' }
  ],
  timeline: [
    { time: '07:12', title: 'Shift started', detail: 'Pre-operation check completed' },
    { time: '08:05', title: 'Earth excavation completed', detail: '58 minutes · 2 minutes under estimate' },
    { time: '09:10', title: 'Trenching started', detail: 'Rainy conditions · predicted 52 minutes' },
    { time: '09:48', title: 'Productive waiting recorded', detail: 'Waiting for truck · supervisor informed' },
    { time: '10:20', title: 'Site memory captured', detail: 'Soft ground on east side' }
  ],
  tasks: [
    { id: 'T001', type: 'Earth excavation', weather: 'Sunny', skill: 'Expert', machineAge: 2, estimate: 60, actual: 58, status: 'Completed' },
    { id: 'T002', type: 'Trenching', weather: 'Rainy', skill: 'Intermediate', machineAge: 4, estimate: 45, actual: 52, status: 'In progress' },
    { id: 'T003', type: 'Material loading', weather: 'Cloudy', skill: 'Beginner', machineAge: 3, estimate: 30, actual: 42, status: 'Queued' },
    { id: 'T004', type: 'Grading', weather: 'Sunny', skill: 'Expert', machineAge: 5, estimate: 35, actual: 33, status: 'Queued' },
    { id: 'T005', type: 'Demolition', weather: 'Windy', skill: 'Intermediate', machineAge: 6, estimate: 90, actual: 105, status: 'Queued' }
  ],
  memories: [
    { id: 'M-12', kind: 'Site', title: 'Soft ground after rain', body: 'On the east side of the trench, use a smaller bucket load and lower operating speed.', task: 'Trenching', confidence: 'High', uses: 4, updated: 'Today, 10:20', author: 'OP1001' },
    { id: 'M-11', kind: 'Workflow', title: 'Truck queue at loading point A', body: 'Productive waiting usually lasts 8–12 minutes between 09:30 and 10:00.', task: 'Material loading', confidence: 'Medium', uses: 7, updated: 'Yesterday', author: 'Crew memory' },
    { id: 'M-10', kind: 'Technique', title: 'First pass in wet soil', body: 'Take a partial first pass to validate ground stability before increasing bucket load.', task: 'Trenching', confidence: 'High', uses: 6, updated: '18 Sep', author: 'OP1004' }
  ],
  lessons: [
    { id: 'L-01', title: 'Wet-ground trenching', reason: 'Recommended for today’s rainy conditions', duration: '4 min', type: 'Micro-guide', progress: 0 },
    { id: 'L-02', title: 'Recognize productive waiting', reason: 'Based on recent truck queue events', duration: '3 min', type: 'Scenario', progress: 35 },
    { id: 'L-03', title: 'Safe bucket loading', reason: 'Build confidence for intermediate operators', duration: '5 min', type: 'Technique', progress: 0 }
  ],
  safety: { blocked: false, lastEvent: null }
};

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(body));
}
function serveFile(res, pathname) {
  const safe = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.normalize(path.join(PUBLIC, safe));
  if (!filePath.startsWith(PUBLIC)) return json(res, 403, { error: 'Forbidden' });
  fs.readFile(filePath, (err, data) => {
    if (err) return json(res, 404, { error: 'Not found' });
    const ext = path.extname(filePath).toLowerCase();
    const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
    res.writeHead(200, { 'Content-Type': (types[ext] || 'application/octet-stream') + '; charset=utf-8' });
    res.end(data);
  });
}
function buildHandover() {
  const outstanding = Math.max(0, state.currentTask.predictedMinutes - state.currentTask.elapsedMinutes);
  return {
    title: `${state.machine.id} · ${state.currentTask.type} handover`,
    generatedAt: new Date().toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    completed: ['Pre-operation safety check', 'Earth excavation task'],
    outstanding: [`${Math.round(outstanding)} minutes of ${state.currentTask.type.toLowerCase()} remaining`, 'Confirm east-side ground condition before continuing'],
    memories: state.memories.filter(m => m.task === state.currentTask.type).slice(0, 3),
    delays: state.reports.filter(r => r.category === 'Workflow delay' || r.category === 'Site condition'),
    recommendation: 'Inspect the east side, use a partial first pass, and update the task estimate after the next cycle.'
  };
}
function collect(req) {
  return new Promise((resolve, reject) => { let body = ''; req.on('data', c => body += c); req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch (e) { reject(e); } }); });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'GET' && url.pathname === '/api/state') return json(res, 200, state);
  if (req.method === 'GET' && url.pathname === '/api/handover') return json(res, 200, buildHandover());
  if (req.method === 'POST' && url.pathname === '/api/report') {
    try {
      const input = await collect(req);
      const report = { id: `R-${Math.floor(100 + Math.random() * 899)}`, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }), source: state.operator.id, severity: input.severity || 'Medium', ...input };
      state.reports.unshift(report);
      state.timeline.push({ time: report.time, title: 'New operator report', detail: report.title });
      if (report.category === 'Site condition') state.memories.unshift({ id: `M-${Math.floor(20 + Math.random() * 70)}`, kind: 'Site', title: report.title, body: report.detail, task: state.currentTask.type, confidence: 'New', uses: 1, updated: 'Just now', author: state.operator.id });
      return json(res, 201, { report, state });
    } catch (e) { return json(res, 400, { error: 'Invalid report' }); }
  }
  if (req.method === 'POST' && url.pathname === '/api/simulate') {
    const input = await collect(req);
    if (input.event === 'seatbelt') { state.telemetry.seatbelt = 'Unfastened'; state.safety.blocked = true; state.safety.lastEvent = 'Seatbelt status unsafe'; state.timeline.push({ time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }), title: 'Safety blocker triggered', detail: 'Seatbelt status unsafe — task continuation blocked' }); }
    if (input.event === 'resolveSeatbelt') { state.telemetry.seatbelt = 'Fastened'; state.safety.blocked = false; state.safety.lastEvent = null; }
    if (input.event === 'truckWait') { state.telemetry.idleMinutes = 63; state.currentTask.predictedMinutes = 59; state.reports.unshift({ id: 'R-SIM', time: 'Now', category: 'Workflow delay', title: 'Waiting for truck', detail: 'Productive waiting identified at loading point A.', location: 'Loading point A', severity: 'Low', source: state.operator.id }); }
    return json(res, 200, state);
  }
  serveFile(res, url.pathname);
});
server.listen(PORT, () => console.log(`CAT WorkMemory running at http://localhost:${PORT}`));
